# Elio

A Django + HTMX dashboard for writing up capstone projects: title, a detailed abstract of at least 50 words (enough lexical depth for TF-IDF), and key domain terms. It has a dark, purple neon interface.

- **Backend:** Django 5.2, SQLite, Django auth, django-allauth (Google/Apple OAuth), Twilio Verify (phone)
- **Frontend:** Django templates, HTMX 2, plain CSS, a small vanilla JS file, and Lucide icons. Everything frontend lives in `frontend/`.

## Quick start (Windows)

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000/. None of the external credentials are needed for this. Email sign-up, login and all project features work out of the box. On macOS or Linux, run `source .venv/bin/activate` and `cp` instead of `copy`.

Run the tests:

```bat
python manage.py test
```

## Project layout

```text
config/            settings, root URLs, HTMX response helpers (htmx.py)
accounts/          login/signup/logout, email-or-username backend, phone (Twilio) flow, Profile model
projects/          Project model, form validation, CRUD + search views
frontend/
  templates/       base.html, dashboard.html, accounts/, projects/, partials/
  static/          css/ (main, dashboard, auth, responsive), js/main.js, images/, vendor/ (htmx, lucide)
```

## How the pieces fit

- Every full-page view renders `dashboard.html`. HTMX requests get only the fragment (for example `projects/project_detail.html`), so deep links like `/projects/<id>/` also work on reload.
- The server sends events in the `HX-Trigger` header. `projectsChanged` refreshes the sidebar list, `toast` shows a notification, `openAuth` opens the login modal, and `closeModal`/`authChanged` fire after a successful login.
- CSRF: `main.js` reads the `csrftoken` cookie on every HTMX request and sends it as `X-CSRFToken`. It reads the cookie each time because Django rotates the token on login.
- Validation happens on the client and again on the server. The abstract needs at least 50 words, the title must be 5–200 characters, and you need 1–20 unique keywords of 50 characters or fewer each.
- If you're logged out, saving a project opens the login modal. Your draft stays in place and is submitted automatically once you log in.
- Ownership: every project query is filtered by `owner=request.user`, so other users' projects return 404.

## Optional: Google sign-in

1. Go to Google Cloud Console → APIs & Services → Credentials → Create credentials → OAuth client ID (type: Web application). Configure the OAuth consent screen if prompted.
2. Add the authorized redirect URI `http://127.0.0.1:8000/auth/google/login/callback/` (and your production equivalent).
3. Put the values in `.env`:
   ```
   GOOGLE_CLIENT_ID=...
   GOOGLE_CLIENT_SECRET=...
   ```
4. Restart the server. The "Continue with Google" button now starts the real OAuth flow. Until then it shows a "not configured" message.

## Optional: Sign in with Apple

You need a paid Apple Developer account. Apple requires HTTPS and a real domain, so this cannot be tested on `127.0.0.1`.

1. Under Certificates, Identifiers & Profiles, create an App ID with "Sign in with Apple" enabled. Then create a **Services ID** (this becomes the client ID) and configure its domain and the return URL `https://<your-domain>/auth/apple/login/callback/`.
2. Create a **Key** with "Sign in with Apple" enabled and download the `.p8` file.
3. Put the values in `.env`:
   ```
   APPLE_CLIENT_ID=com.example.elio.web   # the Services ID
   APPLE_KEY_ID=ABC123DEFG
   APPLE_TEAM_ID=XYZ987TEAM
   APPLE_PRIVATE_KEY_PATH=C:\path\to\AuthKey_ABC123DEFG.p8
   ```

## Optional: Phone sign-in (Twilio Verify)

1. Create a Twilio account, then go to Verify → Services → create a service.
2. Put the values in `.env`:
   ```
   TWILIO_ACCOUNT_SID=AC...
   TWILIO_AUTH_TOKEN=...
   TWILIO_VERIFY_SERVICE_SID=VA...
   ```
3. Restart the server. Twilio generates and checks the codes, and the app accepts a login only after Twilio approves the code. The first verification of a new number creates an account for it. A trial Twilio account can only send to verified numbers.

## Production notes

Set `DJANGO_DEBUG=False`, a long random `DJANGO_SECRET_KEY`, `DJANGO_ALLOWED_HOSTS`, and `DJANGO_SECURE=True` when serving over HTTPS. That last one turns on secure cookies, HSTS and the SSL redirect. Run `python manage.py collectstatic` and serve `staticfiles/` with your web server or WhiteNoise.
