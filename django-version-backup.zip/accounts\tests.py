import json
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import Client, TestCase, override_settings
from django.urls import reverse

from .models import Profile

User = get_user_model()
HX = {"HTTP_HX_REQUEST": "true"}


class AuthModalTests(TestCase):
    def test_modal_renders_login_and_signup(self):
        login = self.client.get(reverse("accounts:modal"), {"mode": "login"}, **HX)
        self.assertContains(login, "Log in or Sign Up")
        self.assertContains(login, "Continue with Google")
        self.assertContains(login, 'name="identifier"')

        signup = self.client.get(reverse("accounts:modal"), {"mode": "signup"}, **HX)
        self.assertContains(signup, 'name="password2"')

    def test_unconfigured_providers_say_so(self):
        for provider in ("google", "apple", "phone"):
            response = self.client.get(reverse("accounts:provider_not_configured", args=[provider]), **HX)
            self.assertContains(response, "configured yet")

    @override_settings(PHONE_AUTH_CONFIGURED=False)
    def test_phone_flow_requires_configuration(self):
        response = self.client.get(reverse("accounts:phone"), **HX)
        self.assertContains(response, "configured yet")


class SignupTests(TestCase):
    def signup(self, **overrides):
        data = {"email": "ada@example.com", "username": "ada", "password1": "Corr3ct-Horse!", "password2": "Corr3ct-Horse!"}
        data.update(overrides)
        return self.client.post(reverse("accounts:signup"), data, **HX)

    def test_signup_creates_hashed_user_and_logs_in(self):
        response = self.signup()
        self.assertEqual(response.status_code, 200)
        user = User.objects.get(username="ada")
        self.assertNotEqual(user.password, "Corr3ct-Horse!")
        self.assertTrue(user.check_password("Corr3ct-Horse!"))
        self.assertEqual(int(self.client.session["_auth_user_id"]), user.pk)
        events = json.loads(response["HX-Trigger"])
        self.assertTrue(events["closeModal"])
        self.assertContains(response, 'hx-swap-oob="true"')

    def test_duplicate_email_and_username_rejected(self):
        User.objects.create_user("ada", "ada@example.com", "x")
        response = self.signup(email="ADA@example.com", username="Ada")
        self.assertContains(response, "An account with this email already exists.")
        self.assertContains(response, "This username is taken.")
        self.assertEqual(User.objects.count(), 1)

    def test_password_mismatch_and_weak_password(self):
        self.assertContains(self.signup(password2="different"), "Passwords don&#x27;t match.")
        self.assertContains(self.signup(password1="123", password2="123"), "too short")
        self.assertFalse(User.objects.exists())


class LoginLogoutTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("grace", "grace@example.com", "Sup3r-Secret!")

    def test_login_with_email_or_username(self):
        for identifier in ("grace@example.com", "Grace"):
            client = Client()
            response = client.post(reverse("accounts:login"), {"identifier": identifier, "password": "Sup3r-Secret!"}, **HX)
            self.assertEqual(response.status_code, 200)
            self.assertIn("_auth_user_id", client.session)

    def test_invalid_credentials(self):
        response = self.client.post(reverse("accounts:login"), {"identifier": "grace", "password": "nope"}, **HX)
        self.assertContains(response, "Incorrect email/username or password.")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_logout_requires_post(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse("accounts:logout")).status_code, 405)
        response = self.client.post(reverse("accounts:logout"))
        self.assertRedirects(response, "/")
        self.assertNotIn("_auth_user_id", self.client.session)

    def test_header_reflects_auth_state(self):
        self.assertContains(self.client.get("/"), "Sign Up")
        self.client.force_login(self.user)
        response = self.client.get("/")
        self.assertNotContains(response, ">Sign Up<")
        self.assertContains(response, "Log out")

    def test_login_requires_csrf_token(self):
        client = Client(enforce_csrf_checks=True)
        response = client.post(reverse("accounts:login"), {"identifier": "grace", "password": "Sup3r-Secret!"}, **HX)
        self.assertEqual(response.status_code, 403)

        client.get("/")  # sets the csrftoken cookie, which main.js sends as X-CSRFToken
        token = client.cookies["csrftoken"].value
        response = client.post(reverse("accounts:login"), {"identifier": "grace", "password": "Sup3r-Secret!"},
                               HTTP_X_CSRFTOKEN=token, **HX)
        self.assertEqual(response.status_code, 200)


@override_settings(PHONE_AUTH_CONFIGURED=True)
class PhoneAuthTests(TestCase):
    @mock.patch("accounts.sms.send_code")
    def test_send_code_stores_number(self, send_code):
        response = self.client.post(reverse("accounts:phone"), {"phone_number": "+1 (555) 123-4567"}, **HX)
        send_code.assert_called_once_with("+15551234567")
        self.assertContains(response, "We sent a code")
        self.assertEqual(self.client.session["phone_verify_number"], "+15551234567")

    def test_invalid_number_rejected(self):
        response = self.client.post(reverse("accounts:phone"), {"phone_number": "12345"}, **HX)
        self.assertContains(response, "international format")

    @mock.patch("accounts.sms.check_code", return_value=False)
    def test_wrong_code_does_not_log_in(self, check_code):
        session = self.client.session
        session["phone_verify_number"] = "+15551234567"
        session.save()
        response = self.client.post(reverse("accounts:phone_verify"), {"code": "000000"}, **HX)
        self.assertContains(response, "incorrect or has expired")
        self.assertNotIn("_auth_user_id", self.client.session)

    @mock.patch("accounts.sms.check_code", return_value=True)
    def test_approved_code_creates_and_logs_in_user(self, check_code):
        session = self.client.session
        session["phone_verify_number"] = "+15551234567"
        session.save()
        self.client.post(reverse("accounts:phone_verify"), {"code": "123456"}, **HX)
        profile = Profile.objects.get(phone_number="+15551234567")
        self.assertFalse(profile.user.has_usable_password())
        self.assertEqual(int(self.client.session["_auth_user_id"]), profile.user.pk)

    def test_verify_without_started_session_fails(self):
        response = self.client.post(reverse("accounts:phone_verify"), {"code": "123456"}, **HX)
        self.assertContains(response, "expired")
        self.assertNotIn("_auth_user_id", self.client.session)
