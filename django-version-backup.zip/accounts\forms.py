import re

from django import forms
from django.contrib.auth import authenticate, get_user_model, password_validation

User = get_user_model()

PHONE_RE = re.compile(r"^\+[1-9]\d{7,14}$")


class LoginForm(forms.Form):
    identifier = forms.CharField(
        label="Email or username",
        max_length=254,
        widget=forms.TextInput(attrs={"autocomplete": "username", "placeholder": "you@example.com"}),
    )
    password = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password", "placeholder": "Password"}),
    )

    def __init__(self, request=None, *args, **kwargs):
        self.request = request
        self.user = None
        super().__init__(*args, **kwargs)

    def clean(self):
        cleaned = super().clean()
        identifier, password = cleaned.get("identifier"), cleaned.get("password")
        if identifier and password:
            self.user = authenticate(self.request, username=identifier.strip(), password=password)
            if self.user is None:
                raise forms.ValidationError("Incorrect email/username or password.")
        return cleaned


class SignupForm(forms.Form):
    email = forms.EmailField(
        label="Email address",
        widget=forms.EmailInput(attrs={"autocomplete": "email", "placeholder": "you@example.com"}),
    )
    username = forms.CharField(
        label="Username",
        max_length=30,
        widget=forms.TextInput(attrs={"autocomplete": "username", "placeholder": "Display name"}),
    )
    password1 = forms.CharField(
        label="Password",
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", "placeholder": "Password"}),
    )
    password2 = forms.CharField(
        label="Confirm password",
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password", "placeholder": "Repeat password"}),
    )

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email

    def clean_username(self):
        username = self.cleaned_data["username"].strip()
        if not re.fullmatch(r"[\w.+-]+", username):
            raise forms.ValidationError("Use letters, numbers and . + - _ only.")
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("This username is taken.")
        return username

    def clean(self):
        cleaned = super().clean()
        p1, p2 = cleaned.get("password1"), cleaned.get("password2")
        if p1 and p2 and p1 != p2:
            self.add_error("password2", "Passwords don't match.")
        elif p1:
            candidate = User(username=cleaned.get("username", ""), email=cleaned.get("email", ""))
            try:
                password_validation.validate_password(p1, candidate)
            except forms.ValidationError as exc:
                self.add_error("password1", exc)
        return cleaned

    def save(self):
        return User.objects.create_user(
            username=self.cleaned_data["username"],
            email=self.cleaned_data["email"],
            password=self.cleaned_data["password1"],
        )


class PhoneForm(forms.Form):
    phone_number = forms.CharField(
        label="Phone number",
        max_length=20,
        widget=forms.TextInput(attrs={"autocomplete": "tel", "placeholder": "+15551234567", "inputmode": "tel"}),
        help_text="International format, including the country code.",
    )

    def clean_phone_number(self):
        number = re.sub(r"[\s()-]", "", self.cleaned_data["phone_number"])
        if not PHONE_RE.match(number):
            raise forms.ValidationError("Enter a number in international format, e.g. +15551234567.")
        return number


class PhoneCodeForm(forms.Form):
    code = forms.CharField(
        label="Verification code",
        max_length=10,
        widget=forms.TextInput(attrs={"autocomplete": "one-time-code", "inputmode": "numeric", "placeholder": "123456"}),
    )

    def clean_code(self):
        code = self.cleaned_data["code"].strip()
        if not code.isdigit() or not 4 <= len(code) <= 10:
            raise forms.ValidationError("Enter the numeric code from the SMS.")
        return code
