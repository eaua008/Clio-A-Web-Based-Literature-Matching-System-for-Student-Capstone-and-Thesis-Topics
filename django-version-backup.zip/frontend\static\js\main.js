/* Elio — small UI behaviours. Data loading and saving is done by HTMX + Django. */
(function () {
  "use strict";

  const root = document.documentElement;
  const isMobile = () => window.matchMedia("(max-width: 768px)").matches;
  const wordCount = (text) => text.trim().split(/\s+/).filter(Boolean).length;

  function getCookie(name) {
    const match = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return match ? decodeURIComponent(match[1]) : "";
  }

  function storage(action, key, value) {
    try {
      if (action === "get") return localStorage.getItem(key);
      localStorage.setItem(key, value);
    } catch (e) { /* storage unavailable */ }
    return null;
  }

  /* ---------- CSRF for every HTMX request ----------
     Read from the cookie each time: Django rotates the token on login. */
  document.addEventListener("htmx:configRequest", (evt) => {
    evt.detail.headers["X-CSRFToken"] = getCookie("csrftoken");
  });

  /* ---------- Toasts ---------- */
  function dismissToast(el) {
    el.classList.add("is-leaving");
    setTimeout(() => el.remove(), 260);
  }

  function showToast(message, level) {
    const container = document.getElementById("toast-root");
    const el = document.createElement("div");
    el.className = "toast toast--" + (level === "error" ? "error" : "success");
    el.textContent = message;
    container.appendChild(el);
    setTimeout(() => dismissToast(el), 4000);
  }

  document.body.addEventListener("toast", (evt) => showToast(evt.detail.message, evt.detail.level));
  document.querySelectorAll("[data-toast]").forEach((el) => setTimeout(() => dismissToast(el), 4000));

  document.body.addEventListener("htmx:responseError", (evt) => {
    const status = evt.detail.xhr.status;
    const message = status === 404 ? "That item could not be found."
      : status === 403 ? "Your session expired. Please reload the page and try again."
      : "Something went wrong. Please try again.";
    showToast(message, "error");
  });
  document.body.addEventListener("htmx:sendError", () => showToast("Network error. Check your connection and try again.", "error"));

  /* ---------- Modal ---------- */
  const modalRoot = document.getElementById("modal-root");
  let lastFocus = null;
  let pendingSubmit = false;

  function focusables(container) {
    return Array.from(container.querySelectorAll(
      'a[href], button:not([disabled]), input:not([type=hidden]):not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter((el) => el.offsetParent !== null);
  }

  function openModal() {
    if (!document.body.classList.contains("modal-open")) {
      lastFocus = document.activeElement;
    }
    document.body.classList.add("modal-open");
    const dialog = modalRoot.querySelector(".modal__dialog");
    const first = dialog && (dialog.querySelector("input:not([type=hidden])") || focusables(dialog)[0]);
    if (first) first.focus();
  }

  function closeModal(byUser) {
    if (!modalRoot.firstElementChild) return;
    modalRoot.innerHTML = "";
    document.body.classList.remove("modal-open");
    if (byUser) pendingSubmit = false;
    if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
  }

  function openAuthModal(mode) {
    htmx.ajax("GET", "/accounts/modal/?mode=" + (mode === "signup" ? "signup" : "login"), { target: "#modal-root" });
  }

  document.body.addEventListener("htmx:afterSettle", (evt) => {
    if (evt.detail.target === modalRoot && modalRoot.firstElementChild) openModal();
    if (modalRoot.contains(evt.detail.target) && evt.detail.target.id === "auth-form") {
      const invalid = evt.detail.target.querySelector(".field--invalid input, input");
      if (invalid) invalid.focus();
    }
  });

  modalRoot.addEventListener("click", (evt) => {
    if (evt.target.closest("[data-modal-close]")) closeModal(true);
  });

  document.body.addEventListener("closeModal", () => closeModal(false));
  document.body.addEventListener("openAuth", (evt) => openAuthModal(evt.detail && evt.detail.value));
  document.body.addEventListener("pendingSubmit", () => { pendingSubmit = true; });

  // After login/signup, finish the save the user attempted while logged out.
  document.body.addEventListener("authChanged", () => {
    const form = document.querySelector("[data-project-form]");
    if (pendingSubmit && form) {
      pendingSubmit = false;
      form.requestSubmit();
    }
  });

  document.addEventListener("keydown", (evt) => {
    if (!document.body.classList.contains("modal-open")) return;
    if (evt.key === "Escape") {
      evt.preventDefault();
      closeModal(true);
    } else if (evt.key === "Tab") {
      const items = focusables(modalRoot);
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (evt.shiftKey && document.activeElement === first) { evt.preventDefault(); last.focus(); }
      else if (!evt.shiftKey && document.activeElement === last) { evt.preventDefault(); first.focus(); }
    }
  });

  /* ---------- Sidebar ---------- */
  const backdrop = document.querySelector(".sidebar-backdrop");

  function setDrawer(open) {
    root.classList.toggle("sidebar-open", open);
    backdrop.hidden = !open;
    const menuBtn = document.querySelector("[data-sidebar-open]");
    if (menuBtn) menuBtn.setAttribute("aria-expanded", String(open));
  }

  function setCollapsed(collapsed) {
    root.classList.toggle("sidebar-collapsed", collapsed);
    storage("set", "elio.sidebar", collapsed ? "collapsed" : "expanded");
    document.querySelectorAll("[data-sidebar-toggle]").forEach((btn) => {
      const label = collapsed ? "Expand sidebar" : "Collapse sidebar";
      btn.setAttribute("aria-label", label);
      btn.title = label;
      btn.setAttribute("aria-expanded", String(!collapsed));
    });
  }
  setCollapsed(root.classList.contains("sidebar-collapsed"));

  function setSearch(open) {
    const box = document.getElementById("project-search");
    const input = document.getElementById("project-search-input");
    const toggle = document.querySelector("[data-search-toggle]");
    box.hidden = !open;
    toggle.setAttribute("aria-expanded", String(open));
    if (open) {
      input.focus();
    } else if (input.value) {
      input.value = "";
      htmx.trigger(input, "search");
    }
  }

  document.addEventListener("click", (evt) => {
    const target = evt.target;
    if (target.closest("[data-sidebar-toggle]")) setCollapsed(!root.classList.contains("sidebar-collapsed"));
    if (target.closest("[data-sidebar-open]")) setDrawer(true);
    if (target.closest("[data-sidebar-close]")) setDrawer(false);
    if (target.closest("[data-sidebar-nav]") && isMobile()) setDrawer(false);

    if (target.closest("[data-search-toggle]")) {
      if (root.classList.contains("sidebar-collapsed") && !isMobile()) {
        setCollapsed(false);
        setSearch(true);
      } else {
        setSearch(document.getElementById("project-search").hidden);
      }
    }

    // Profile dropdown
    const menuToggle = target.closest("[data-menu-toggle]");
    const menu = document.getElementById("profile-menu");
    if (menu) {
      if (menuToggle) {
        menu.hidden = !menu.hidden;
        menuToggle.setAttribute("aria-expanded", String(!menu.hidden));
      } else if (!target.closest("#profile-menu")) {
        closeProfileMenu();
      }
    }
  });

  function closeProfileMenu() {
    const menu = document.getElementById("profile-menu");
    if (menu && !menu.hidden) {
      menu.hidden = true;
      document.querySelector("[data-menu-toggle]").setAttribute("aria-expanded", "false");
    }
  }

  document.addEventListener("keydown", (evt) => {
    if (evt.key !== "Escape" || document.body.classList.contains("modal-open")) return;
    closeProfileMenu();
    if (root.classList.contains("sidebar-open")) setDrawer(false);
  });

  function markActiveProject() {
    document.querySelectorAll(".project-link").forEach((link) => {
      const active = link.getAttribute("href") === window.location.pathname
        || window.location.pathname.startsWith(link.getAttribute("href") + "edit/");
      link.classList.toggle("is-active", active);
      if (active) link.setAttribute("aria-current", "page"); else link.removeAttribute("aria-current");
    });
  }
  document.body.addEventListener("htmx:afterSettle", markActiveProject);
  window.addEventListener("popstate", () => setTimeout(markActiveProject, 50));

  /* ---------- Project form ---------- */
  function initProjectForm(form) {
    if (form.dataset.ready) return;
    form.dataset.ready = "1";

    const minWords = parseInt(form.dataset.minWords, 10) || 50;
    const isEdit = !form.querySelector("[data-clear]");
    const title = form.elements.title;
    const abstract = form.querySelector("[data-word-source]");
    const counter = form.querySelector("[data-word-count]");
    const hint = form.querySelector("[data-word-hint]");
    const tagList = form.querySelector("[data-tag-list]");
    const tagStore = form.querySelector("[data-tag-store]");
    const tagInput = form.querySelector("#keyword-input");
    const addBtn = form.querySelector("[data-tag-add]");

    let tags = [];
    try { tags = JSON.parse(tagStore.value || "[]"); } catch (e) { tags = []; }

    const snapshot = () => JSON.stringify([title.value, abstract.value, tags]);
    const initial = snapshot();

    form.isDirty = () => isEdit
      ? snapshot() !== initial
      : Boolean(title.value.trim() || abstract.value.trim() || tags.length || tagInput.value.trim());

    function setError(name, message) {
      const el = form.querySelector('[data-error-for="' + name + '"]');
      if (!el) return;
      el.textContent = message || "";
      el.closest(".field").classList.toggle("field--invalid", Boolean(message));
      const input = name === "keywords" ? tagInput : form.elements[name];
      if (input) {
        if (message) input.setAttribute("aria-invalid", "true"); else input.removeAttribute("aria-invalid");
      }
    }

    function updateCount() {
      const count = wordCount(abstract.value);
      counter.textContent = count + " / " + minWords + " words";
      const low = count > 0 && count < minWords;
      counter.classList.toggle("is-low", low);
      counter.classList.toggle("is-ok", count >= minWords);
      hint.classList.toggle("is-warning", low);
    }

    function renderTags() {
      tagStore.value = JSON.stringify(tags);
      tagList.innerHTML = "";
      tags.forEach((tag) => {
        const li = document.createElement("li");
        li.className = "tag";
        li.dataset.tag = tag;
        const span = document.createElement("span");
        span.textContent = tag;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "tag__remove";
        btn.setAttribute("aria-label", "Remove " + tag);
        btn.innerHTML = '<i data-lucide="x"></i>';
        li.append(span, btn);
        tagList.appendChild(li);
      });
      if (window.lucide) lucide.createIcons();
    }

    function addTag() {
      const value = tagInput.value.replace(/\s+/g, " ").trim();
      if (!value) return;
      if (value.length > 50) return setError("keywords", "Keywords must be at most 50 characters.");
      if (tags.some((t) => t.toLowerCase() === value.toLowerCase())) {
        return setError("keywords", "“" + value + "” has already been added.");
      }
      if (tags.length >= 20) return setError("keywords", "Use at most 20 keywords.");
      tags.push(value);
      tagInput.value = "";
      setError("keywords", "");
      renderTags();
      tagInput.focus();
    }

    tagInput.addEventListener("keydown", (evt) => {
      if (evt.key === "Enter") { evt.preventDefault(); addTag(); }
      else if (evt.key === "Backspace" && !tagInput.value && tags.length) { tags.pop(); renderTags(); }
    });
    addBtn.addEventListener("click", addTag);
    tagList.addEventListener("click", (evt) => {
      const btn = evt.target.closest(".tag__remove");
      if (!btn) return;
      const tag = btn.closest(".tag").dataset.tag;
      tags = tags.filter((t) => t !== tag);
      renderTags();
      tagInput.focus();
    });

    abstract.addEventListener("input", () => {
      updateCount();
      if (wordCount(abstract.value) >= minWords) setError("abstract", "");
    });
    title.addEventListener("input", () => { if (title.value.trim()) setError("title", ""); });

    function validate() {
      let ok = true;
      const t = title.value.trim();
      if (!t) { setError("title", "Please enter a project title."); ok = false; }
      else if (t.length < 5) { setError("title", "The title should be at least 5 characters long."); ok = false; }
      else setError("title", "");

      const count = wordCount(abstract.value);
      if (count < minWords) {
        setError("abstract", "Please write at least " + minWords + " words to ensure the TF-IDF vectorizer has sufficient lexical depth (" + count + "/" + minWords + " so far).");
        ok = false;
      } else setError("abstract", "");

      if (tagInput.value.trim()) addTag();  // count a typed-but-not-added keyword
      if (!tags.length) { setError("keywords", "Add at least one key domain term."); ok = false; }
      else setError("keywords", "");
      return ok;
    }

    form.addEventListener("htmx:beforeRequest", (evt) => {
      if (evt.detail.elt !== form) return;
      if (!validate()) {
        evt.preventDefault();
        const firstInvalid = form.querySelector(".field--invalid input:not([type=hidden]), .field--invalid textarea");
        if (firstInvalid) firstInvalid.focus();
      }
    });

    const clearBtn = form.querySelector("[data-clear]");
    if (clearBtn) {
      clearBtn.addEventListener("click", () => {
        if (form.isDirty() && !window.confirm("Discard the unsaved project details?")) return;
        title.value = "";
        abstract.value = "";
        tagInput.value = "";
        tags = [];
        renderTags();
        ["title", "abstract", "keywords"].forEach((n) => setError(n, ""));
        const alert = form.querySelector(".form-alert");
        if (alert) alert.remove();
        updateCount();
        title.focus();
      });
    }

    updateCount();
  }

  // Ask before navigating away from unsaved form content via HTMX.
  document.body.addEventListener("htmx:confirm", (evt) => {
    const form = document.querySelector("[data-project-form]");
    const elt = evt.detail.elt;
    if (!form || !form.isDirty || form.contains(elt) || modalRoot.contains(elt)) return;
    if (evt.detail.target && evt.detail.target.id === "main-content" && form.isDirty()) {
      evt.preventDefault();
      if (window.confirm("You have unsaved changes. Leave this form?")) evt.detail.issueRequest();
    }
  });

  window.addEventListener("beforeunload", (evt) => {
    const form = document.querySelector("[data-project-form]");
    if (form && form.isDirty && form.isDirty()) { evt.preventDefault(); evt.returnValue = ""; }
  });
  // Logging out is a deliberate full-page navigation; don't block it.
  document.addEventListener("submit", (evt) => {
    if (!evt.target.hasAttribute("hx-post")) {
      const form = document.querySelector("[data-project-form]");
      if (form) form.isDirty = () => false;
    }
  });

  /* ---------- Boot ---------- */
  htmx.onLoad((content) => {
    if (window.lucide) lucide.createIcons();
    const forms = content.matches && content.matches("[data-project-form]")
      ? [content] : Array.from(content.querySelectorAll ? content.querySelectorAll("[data-project-form]") : []);
    forms.forEach(initProjectForm);
  });

  markActiveProject();

  const params = new URLSearchParams(window.location.search);
  if (params.has("auth")) {
    openAuthModal(params.get("auth"));
    params.delete("auth");
    const query = params.toString();
    history.replaceState(null, "", window.location.pathname + (query ? "?" + query : ""));
  }
})();
