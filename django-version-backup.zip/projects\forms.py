import json

from django import forms

from .models import Project

MIN_ABSTRACT_WORDS = 50
MAX_ABSTRACT_CHARS = 10000
MAX_KEYWORDS = 20
MAX_KEYWORD_LENGTH = 50


class ProjectForm(forms.ModelForm):
    # The keyword tag widget keeps this hidden field in sync as a JSON array.
    keywords = forms.CharField(required=False, widget=forms.HiddenInput)

    class Meta:
        model = Project
        fields = ["title", "abstract", "keywords"]
        labels = {
            "title": "Project / Capstone Title",
            "abstract": "Detailed Abstract / Technical Summary",
        }
        widgets = {
            "title": forms.TextInput(attrs={
                "placeholder": "e.g., Low-Cost Opto-Mechanical Seedling and Grain Sorter",
                "maxlength": 200,
                "autocomplete": "off",
            }),
            "abstract": forms.Textarea(attrs={
                "rows": 7,
                "maxlength": MAX_ABSTRACT_CHARS,
                "placeholder": (
                    "Describe your project in detail: the problem it solves, the hardware and software "
                    "components, mechanisms, algorithms or models used, and the performance goals you "
                    "are targeting."
                ),
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not self.is_bound and self.instance.pk:
            self.initial["keywords"] = json.dumps(self.instance.keywords)

    @property
    def keyword_list(self):
        """Keywords to render as tags (bound data first, so they survive errors)."""
        raw = self.data.get("keywords") if self.is_bound else self.initial.get("keywords")
        try:
            value = json.loads(raw or "[]")
        except (TypeError, ValueError):
            return []
        return [str(k) for k in value] if isinstance(value, list) else []

    @property
    def keywords_json(self):
        return json.dumps(self.keyword_list)

    def clean_title(self):
        title = " ".join(self.cleaned_data["title"].split())
        if not title:
            raise forms.ValidationError("Please enter a project title.")
        if len(title) < 5:
            raise forms.ValidationError("The title should be at least 5 characters long.")
        return title

    def clean_abstract(self):
        abstract = self.cleaned_data["abstract"].strip()
        if len(abstract) > MAX_ABSTRACT_CHARS:
            raise forms.ValidationError(f"The abstract must be under {MAX_ABSTRACT_CHARS} characters.")
        words = len(abstract.split())
        if words < MIN_ABSTRACT_WORDS:
            raise forms.ValidationError(
                f"Please write at least {MIN_ABSTRACT_WORDS} words to ensure the TF-IDF vectorizer has "
                f"sufficient lexical depth ({words}/{MIN_ABSTRACT_WORDS} so far)."
            )
        return abstract

    def clean_keywords(self):
        raw = self.cleaned_data.get("keywords") or "[]"
        try:
            values = json.loads(raw)
        except ValueError:
            raise forms.ValidationError("Keywords could not be read. Please re-add them.")
        if not isinstance(values, list):
            raise forms.ValidationError("Keywords could not be read. Please re-add them.")

        keywords, seen = [], set()
        for value in values:
            keyword = " ".join(str(value).split())
            if not keyword:
                continue
            if len(keyword) > MAX_KEYWORD_LENGTH:
                raise forms.ValidationError(f"Keywords must be at most {MAX_KEYWORD_LENGTH} characters.")
            if keyword.lower() not in seen:
                seen.add(keyword.lower())
                keywords.append(keyword)
        if not keywords:
            raise forms.ValidationError("Add at least one key domain term.")
        if len(keywords) > MAX_KEYWORDS:
            raise forms.ValidationError(f"Use at most {MAX_KEYWORDS} keywords.")
        return keywords
