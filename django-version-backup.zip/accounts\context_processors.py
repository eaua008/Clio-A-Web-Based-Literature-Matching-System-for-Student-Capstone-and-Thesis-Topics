from django.conf import settings


def auth_providers(request):
    return {
        "google_configured": settings.GOOGLE_CONFIGURED,
        "apple_configured": settings.APPLE_CONFIGURED,
        "phone_configured": settings.PHONE_AUTH_CONFIGURED,
    }
