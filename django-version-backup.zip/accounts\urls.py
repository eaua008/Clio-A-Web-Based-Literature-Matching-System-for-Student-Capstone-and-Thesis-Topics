from django.urls import path

from . import views

app_name = "accounts"

urlpatterns = [
    path("modal/", views.auth_modal, name="modal"),
    path("form/", views.auth_form, name="form"),
    path("login/", views.login_view, name="login"),
    path("signup/", views.signup_view, name="signup"),
    path("logout/", views.logout_view, name="logout"),
    path("phone/", views.phone_start, name="phone"),
    path("phone/verify/", views.phone_verify, name="phone_verify"),
    path("provider/<str:provider>/", views.provider_not_configured, name="provider_not_configured"),
]
