import json

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Project

User = get_user_model()
HX = {"HTTP_HX_REQUEST": "true"}
ABSTRACT = " ".join(f"word{i}" for i in range(60))


def project_data(**overrides):
    data = {
        "title": "Low-Cost Opto-Mechanical Grain Sorter",
        "abstract": ABSTRACT,
        "keywords": json.dumps(["grain sorter", "optical sensor"]),
    }
    data.update(overrides)
    return data


class ProjectCreateTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("ada", "ada@example.com", "pw")
        self.client.force_login(self.user)

    def post(self, **overrides):
        return self.client.post(reverse("projects:create"), project_data(**overrides), **HX)

    def test_dashboard_loads(self):
        response = self.client.get("/")
        self.assertContains(response, "New Project")
        self.assertContains(response, "Project / Capstone Title")
        self.assertContains(response, "TF-IDF vectorizer")

    def test_valid_project_saved_and_list_refresh_triggered(self):
        response = self.post()
        project = Project.objects.get()
        self.assertEqual(project.owner, self.user)
        self.assertEqual(project.keywords, ["grain sorter", "optical sensor"])
        events = json.loads(response["HX-Trigger"])
        self.assertTrue(events["projectsChanged"])
        self.assertIn("saved", events["toast"]["message"])
        self.assertContains(response, 'value=""')  # a fresh, empty form comes back

    def test_abstract_needs_50_words(self):
        response = self.post(abstract=" ".join(["word"] * 49))
        self.assertContains(response, "at least 50 words")
        self.assertContains(response, "49/50")
        self.assertFalse(Project.objects.exists())

    def test_exactly_50_words_accepted(self):
        self.post(abstract=" ".join(["word"] * 50))
        self.assertEqual(Project.objects.count(), 1)

    def test_title_required(self):
        response = self.post(title="   ")
        self.assertContains(response, "This field is required")
        self.assertFalse(Project.objects.exists())

    def test_title_max_length(self):
        response = self.post(title="x" * 201)
        self.assertContains(response, "at most 200 characters")
        self.assertFalse(Project.objects.exists())

    def test_keywords_required_deduplicated_and_validated(self):
        self.assertContains(self.post(keywords="[]"), "Add at least one key domain term.")
        self.assertContains(self.post(keywords="not json"), "could not be read")
        self.assertContains(self.post(keywords=json.dumps(["x" * 51])), "at most 50 characters")
        self.assertFalse(Project.objects.exists())

        self.post(keywords=json.dumps(["ML", "ml", " Machine   learning "]))
        self.assertEqual(Project.objects.get().keywords, ["ML", "Machine learning"])

    def test_invalid_submission_keeps_entered_data(self):
        response = self.post(abstract="too short")
        self.assertContains(response, "Low-Cost Opto-Mechanical Grain Sorter")
        self.assertContains(response, "grain sorter")


class AnonymousAccessTests(TestCase):
    def test_anonymous_cannot_save_and_is_asked_to_log_in(self):
        response = self.client.post(reverse("projects:create"), project_data(), **HX)
        self.assertFalse(Project.objects.exists())
        events = json.loads(response["HX-Trigger"])
        self.assertEqual(events["openAuth"], "login")
        self.assertTrue(events["pendingSubmit"])
        self.assertContains(response, "Please log in")
        self.assertContains(response, "Low-Cost Opto-Mechanical Grain Sorter")  # draft preserved

    def test_anonymous_project_pages(self):
        owner = User.objects.create_user("ada", "ada@example.com", "pw")
        project = Project.objects.create(owner=owner, title="Secret", abstract=ABSTRACT, keywords=["a"])
        response = self.client.get(reverse("projects:detail", args=[project.pk]), **HX)
        self.assertEqual(response.status_code, 204)
        self.assertEqual(json.loads(response["HX-Trigger"])["openAuth"], "login")
        self.assertRedirects(self.client.get(reverse("projects:detail", args=[project.pk])), "/?auth=login",
                             fetch_redirect_response=False)
        self.assertContains(self.client.get(reverse("projects:list"), **HX), "Log in to see your saved projects")


class OwnershipAndCrudTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user("ada", "ada@example.com", "pw")
        self.other = User.objects.create_user("eve", "eve@example.com", "pw")
        self.project = Project.objects.create(
            owner=self.owner, title="Grain Sorter", abstract=ABSTRACT, keywords=["optical sensor"])

    def test_other_users_get_404_everywhere(self):
        self.client.force_login(self.other)
        pk = self.project.pk
        self.assertEqual(self.client.get(reverse("projects:detail", args=[pk]), **HX).status_code, 404)
        self.assertEqual(self.client.get(reverse("projects:edit", args=[pk]), **HX).status_code, 404)
        self.assertEqual(self.client.post(reverse("projects:edit", args=[pk]), project_data(title="Hacked"), **HX).status_code, 404)
        self.assertEqual(self.client.post(reverse("projects:delete", args=[pk]), **HX).status_code, 404)
        self.assertNotContains(self.client.get(reverse("projects:list"), **HX), "Grain Sorter")
        self.project.refresh_from_db()
        self.assertEqual(self.project.title, "Grain Sorter")

    def test_detail_partial_and_full_page(self):
        self.client.force_login(self.owner)
        url = reverse("projects:detail", args=[self.project.pk])
        partial = self.client.get(url, **HX)
        self.assertContains(partial, "optical sensor")
        self.assertNotContains(partial, "<html")
        full = self.client.get(url)
        self.assertContains(full, "<html")
        self.assertContains(full, "optical sensor")

    def test_edit(self):
        self.client.force_login(self.owner)
        url = reverse("projects:edit", args=[self.project.pk])
        self.assertContains(self.client.get(url, **HX), "Save changes")
        response = self.client.post(url, project_data(title="Improved Grain Sorter"), **HX)
        self.project.refresh_from_db()
        self.assertEqual(self.project.title, "Improved Grain Sorter")
        self.assertEqual(response["HX-Push-Url"], reverse("projects:detail", args=[self.project.pk]))
        self.assertTrue(json.loads(response["HX-Trigger"])["projectsChanged"])

    def test_edit_validation(self):
        self.client.force_login(self.owner)
        response = self.client.post(reverse("projects:edit", args=[self.project.pk]), project_data(abstract="short"), **HX)
        self.assertContains(response, "at least 50 words")
        self.project.refresh_from_db()
        self.assertEqual(self.project.abstract, ABSTRACT)

    def test_delete_requires_post(self):
        self.client.force_login(self.owner)
        url = reverse("projects:delete", args=[self.project.pk])
        self.assertEqual(self.client.get(url, **HX).status_code, 405)
        response = self.client.post(url, **HX)
        self.assertFalse(Project.objects.exists())
        self.assertIn("deleted", json.loads(response["HX-Trigger"])["toast"]["message"])

    def test_search_by_title_and_keyword(self):
        Project.objects.create(owner=self.owner, title="Drone Mapper", abstract=ABSTRACT, keywords=["lidar"])
        Project.objects.create(owner=self.other, title="Grain Thief", abstract=ABSTRACT, keywords=["optical"])
        self.client.force_login(self.owner)
        url = reverse("projects:list")

        by_title = self.client.get(url, {"q": "grain"}, **HX)
        self.assertContains(by_title, "Grain Sorter")
        self.assertNotContains(by_title, "Drone Mapper")
        self.assertNotContains(by_title, "Grain Thief")

        by_keyword = self.client.get(url, {"q": "LIDAR"}, **HX)
        self.assertContains(by_keyword, "Drone Mapper")
        self.assertNotContains(by_keyword, "Grain Sorter")

        self.assertContains(self.client.get(url, {"q": "zzz"}, **HX), "No projects match")

    def test_empty_state(self):
        self.client.force_login(self.other)
        self.assertContains(self.client.get(reverse("projects:list"), **HX), "No projects yet")
