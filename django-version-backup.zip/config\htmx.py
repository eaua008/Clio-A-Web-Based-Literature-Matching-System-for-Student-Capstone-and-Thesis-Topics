"""Small helpers for HTMX responses."""
import json


def is_htmx(request):
    return request.headers.get("HX-Request") == "true"


def trigger(response, **events):
    """Attach client-side events (HX-Trigger header) to a response.

    Events are merged with any already present, so helpers can be stacked.
    """
    existing = json.loads(response.headers.get("HX-Trigger", "{}"))
    existing.update(events)
    response["HX-Trigger"] = json.dumps(existing)
    return response


def toast(response, message, level="success"):
    return trigger(response, toast={"message": message, "level": level})
