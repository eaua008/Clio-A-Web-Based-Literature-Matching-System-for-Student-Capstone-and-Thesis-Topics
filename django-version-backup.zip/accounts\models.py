from django.conf import settings
from django.db import models


class Profile(models.Model):
    """Extra per-user data. Holds the verified phone number for phone sign-in."""

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    phone_number = models.CharField(max_length=20, unique=True, null=True, blank=True)

    def __str__(self):
        return f"Profile({self.user})"
