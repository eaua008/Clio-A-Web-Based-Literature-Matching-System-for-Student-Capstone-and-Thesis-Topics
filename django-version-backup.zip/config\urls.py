from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("accounts/", include("accounts.urls")),
    # django-allauth handles the OAuth redirects/callbacks (Google, Apple).
    path("auth/", include("allauth.urls")),
    path("", include("projects.urls")),
]
