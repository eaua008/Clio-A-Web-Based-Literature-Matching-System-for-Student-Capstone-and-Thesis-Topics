from functools import wraps

from django.db.models import Q
from django.http import HttpResponse
from django.middleware.csrf import get_token
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_GET, require_http_methods, require_POST

from config.htmx import is_htmx, toast, trigger

from .forms import MIN_ABSTRACT_WORDS, ProjectForm
from .models import Project


def _render_page(request, template, context=None, status=200):
    """HTMX requests get the fragment; normal requests get the full dashboard around it."""
    context = context or {}
    if is_htmx(request) and not request.headers.get("HX-History-Restore-Request"):
        return render(request, template, context, status=status)
    get_token(request)  # full pages must set the CSRF cookie that HTMX reads
    context["content_template"] = template
    context["projects"] = _user_projects(request)
    return render(request, "dashboard.html", context, status=status)


def _user_projects(request, query=""):
    if not request.user.is_authenticated:
        return Project.objects.none()
    projects = Project.objects.filter(owner=request.user)
    if query:
        projects = projects.filter(Q(title__icontains=query) | Q(keywords__icontains=query))
    return projects


def login_required_htmx(view):
    """Like login_required, but asks HTMX callers to open the login modal."""

    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            return view(request, *args, **kwargs)
        if is_htmx(request):
            response = HttpResponse(status=204)
            trigger(response, openAuth="login")
            return toast(response, "Please log in to continue.", "error")
        return redirect("/?auth=login")

    return wrapper


def _form_context(form, project=None):
    return {"form": form, "project": project, "min_words": MIN_ABSTRACT_WORDS}


@require_GET
def dashboard(request):
    return _render_page(request, "projects/project_form.html", _form_context(ProjectForm()))


@require_GET
def project_list(request):
    query = request.GET.get("q", "").strip()[:100]
    return render(request, "projects/project_list.html", {
        "projects": _user_projects(request, query),
        "query": query,
    })


@require_http_methods(["GET", "POST"])
def project_create(request):
    if request.method == "GET":
        return _render_page(request, "projects/project_form.html", _form_context(ProjectForm()))

    form = ProjectForm(data=request.POST)
    if not request.user.is_authenticated:
        # Keep everything the user typed and ask them to log in; the client
        # resubmits automatically once authentication succeeds.
        form.is_valid()
        form.add_error(None, "Please log in or sign up to save your project. Your draft is kept.")
        response = render(request, "projects/project_form.html", _form_context(form))
        return trigger(response, openAuth="login", pendingSubmit=True)

    if not form.is_valid():
        return render(request, "projects/project_form.html", _form_context(form))

    project = form.save(commit=False)
    project.owner = request.user
    project.save()
    response = render(request, "projects/project_form.html", _form_context(ProjectForm()))
    trigger(response, projectsChanged=True)
    return toast(response, f"“{project.title}” saved.")


@require_GET
@login_required_htmx
def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk, owner=request.user)
    return _render_page(request, "projects/project_detail.html", {"project": project})


@require_http_methods(["GET", "POST"])
@login_required_htmx
def project_edit(request, pk):
    project = get_object_or_404(Project, pk=pk, owner=request.user)
    if request.method == "GET":
        return _render_page(request, "projects/project_form.html", _form_context(ProjectForm(instance=project), project))

    form = ProjectForm(data=request.POST, instance=project)
    if not form.is_valid():
        return render(request, "projects/project_form.html", _form_context(form, project))
    project = form.save()
    response = render(request, "projects/project_detail.html", {"project": project})
    response["HX-Push-Url"] = reverse("projects:detail", args=[project.pk])
    trigger(response, projectsChanged=True)
    return toast(response, "Project updated.")


@require_POST
@login_required_htmx
def project_delete(request, pk):
    project = get_object_or_404(Project, pk=pk, owner=request.user)
    title = project.title
    project.delete()
    response = render(request, "projects/project_form.html", _form_context(ProjectForm()))
    response["HX-Push-Url"] = reverse("projects:dashboard")
    trigger(response, projectsChanged=True)
    return toast(response, f"“{title}” deleted.")
