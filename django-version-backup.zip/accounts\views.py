import secrets

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model, login, logout
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.template.loader import render_to_string
from django.views.decorators.http import require_GET, require_POST, require_http_methods

from config.htmx import toast, trigger

from . import sms
from .forms import LoginForm, PhoneCodeForm, PhoneForm, SignupForm
from .models import Profile

User = get_user_model()

BACKEND = "accounts.backends.EmailOrUsernameBackend"
PHONE_SESSION_KEY = "phone_verify_number"

PROVIDER_NAMES = {"google": "Google", "apple": "Apple", "phone": "Phone"}
PROVIDER_SETUP = {
    "google": "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in .env (see README).",
    "apple": "Set the APPLE_* variables and the .p8 key path in .env (see README).",
    "phone": "Set the TWILIO_* variables in .env (see README).",
}


def _auth_success(request, user, message):
    """Log in, then refresh the header nav out-of-band and close the modal."""
    login(request, user, backend=BACKEND)
    html = render_to_string("partials/auth_nav.html", {"oob": True}, request=request)
    response = HttpResponse(html)
    response["HX-Reswap"] = "none"
    trigger(response, closeModal=True, authChanged=True, projectsChanged=True)
    return toast(response, message)


@require_GET
def auth_modal(request):
    mode = "signup" if request.GET.get("mode") == "signup" else "login"
    form = SignupForm() if mode == "signup" else LoginForm()
    return render(request, "accounts/auth_modal.html", {"mode": mode, "form": form})


@require_GET
def auth_form(request):
    """Swap between the login and signup forms inside an open modal."""
    if request.GET.get("mode") == "signup":
        return render(request, "accounts/signup_form.html", {"form": SignupForm()})
    return render(request, "accounts/login_form.html", {"form": LoginForm()})


@require_http_methods(["GET", "POST"])
def login_view(request):
    if request.method == "GET":
        return redirect("/?auth=login")
    form = LoginForm(request, data=request.POST)
    if not form.is_valid():
        return render(request, "accounts/login_form.html", {"form": form})
    return _auth_success(request, form.user, f"Welcome back, {form.user.username}!")


@require_http_methods(["GET", "POST"])
def signup_view(request):
    if request.method == "GET":
        return redirect("/?auth=signup")
    form = SignupForm(data=request.POST)
    if not form.is_valid():
        return render(request, "accounts/signup_form.html", {"form": form})
    user = form.save()
    return _auth_success(request, user, f"Account created. Welcome, {user.username}!")


@require_POST
def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("/")


@require_GET
def provider_not_configured(request, provider):
    if provider not in PROVIDER_NAMES:
        return HttpResponse(status=404)
    return render(request, "accounts/provider_message.html", {
        "provider": PROVIDER_NAMES[provider],
        "setup": PROVIDER_SETUP[provider],
    })


@require_http_methods(["GET", "POST"])
def phone_start(request):
    if not settings.PHONE_AUTH_CONFIGURED:
        return render(request, "accounts/provider_message.html", {
            "provider": "Phone", "setup": PROVIDER_SETUP["phone"]})
    if request.method == "GET":
        return render(request, "accounts/phone_form.html", {"form": PhoneForm()})

    form = PhoneForm(data=request.POST)
    if form.is_valid():
        number = form.cleaned_data["phone_number"]
        try:
            sms.send_code(number)
        except sms.SMSError as exc:
            form.add_error("phone_number", str(exc))
        else:
            request.session[PHONE_SESSION_KEY] = number
            return render(request, "accounts/phone_code_form.html", {"form": PhoneCodeForm(), "phone": number})
    return render(request, "accounts/phone_form.html", {"form": form})


@require_POST
def phone_verify(request):
    number = request.session.get(PHONE_SESSION_KEY)
    if not settings.PHONE_AUTH_CONFIGURED or not number:
        return render(request, "accounts/phone_form.html", {
            "form": PhoneForm(), "error": "Your verification session expired. Enter your number again."})

    form = PhoneCodeForm(data=request.POST)
    if form.is_valid():
        try:
            approved = sms.check_code(number, form.cleaned_data["code"])
        except sms.SMSError as exc:
            form.add_error("code", str(exc))
        else:
            if approved:
                del request.session[PHONE_SESSION_KEY]
                profile = Profile.objects.select_related("user").filter(phone_number=number).first()
                if profile:
                    user = profile.user
                else:
                    user = User(username=f"user_{number[-4:]}_{secrets.token_hex(3)}")
                    user.set_unusable_password()
                    user.save()
                    Profile.objects.create(user=user, phone_number=number)
                return _auth_success(request, user, "Phone verified. You're signed in.")
            form.add_error("code", "That code is incorrect or has expired.")
    return render(request, "accounts/phone_code_form.html", {"form": form, "phone": number})
