from django.urls import path

from . import views

app_name = "projects"

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("projects/", views.project_list, name="list"),
    path("projects/new/", views.project_create, name="create"),
    path("projects/<uuid:pk>/", views.project_detail, name="detail"),
    path("projects/<uuid:pk>/edit/", views.project_edit, name="edit"),
    path("projects/<uuid:pk>/delete/", views.project_delete, name="delete"),
]
