"""Thin wrapper around Twilio Verify. Codes are generated and checked by Twilio."""
from django.conf import settings


class SMSError(Exception):
    pass


def _client():
    from twilio.rest import Client

    return Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)


def _service():
    return _client().verify.v2.services(settings.TWILIO_VERIFY_SERVICE_SID)


def send_code(phone_number):
    from twilio.base.exceptions import TwilioException

    try:
        _service().verifications.create(to=phone_number, channel="sms")
    except TwilioException as exc:
        raise SMSError("We couldn't send a code to that number.") from exc


def check_code(phone_number, code):
    from twilio.base.exceptions import TwilioException

    try:
        result = _service().verification_checks.create(to=phone_number, code=code)
    except TwilioException as exc:
        raise SMSError("Verification failed. Request a new code and try again.") from exc
    return result.status == "approved"
